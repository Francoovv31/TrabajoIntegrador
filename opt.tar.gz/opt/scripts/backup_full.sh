#!/bin/bash
function mostrar_ayuda(){
	echo "Uso: $0<directorio_origen> <directorio_destino>]"
	echo "Script para realizar backups de directorios."
	echo "Parámetros:"
	echo " directorio_origen: Directorio a respaldar."
	echo " directorio_destino: Directorio donde se guardará el backup."
	echo "Opciones:"
	echo " -h Muestra esta ayuda."
	exit 0
}
if [[ "$1" == "-h" ]]; then
	mostrar_ayuda
fi
if [[ $# -ne 2 ]]; then
	echo "Error: Se requieren dos parámetros (origen y destino)."
	echo "Use $0 -h para más información."
	exit 1
fi
ORIGEN=$1
DESTINO=$2                                                                                                                                                                                                                                                                                                                                                         DESTINO=$2
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio origen '$ORIGEN' no existe o no está montado."
	exit 1
fi
if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El directorio destino '$DESTINO' no existe o no está montado."
	exit 1
fi
FECHA=$(date +%Y%m%d)
NOMBRE_BACKUP="$(basename "$ORIGEN")bkp${FECHA}.tar.gz"

echo "Iniciando backup de $ORIGEN a $DESTINO/$NOMBRE_BACKUP..."

tar -czf "$DESTINO/$NOMBRE_BACKUP" -C "$ORIGEN" .
if [[ $? -eq 0 ]]; then
	echo "Backup completado exitosamente: $DESTINO/$NOMBRE_BACKUP"
else
	echo "Error al realizar el backup."
	exit 1
fi
