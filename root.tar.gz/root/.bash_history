history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
nano /etc/apt/sources.list
vi /etc/apt/sources.list
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt-get install openssh-server
apt-get install ssh
poweroff
vi /etc/apt/sources.list
apt-get install openssh-server
apt-get -y install openssh-server
apt-get -y install nano
vi /etc/apt/sources.list
cp /etc/apt/sources.list /etc/apt/sources.list.bkp
vi /etc/apt/sources.list
apt update
apt upgrade
vi /etc/apt/sources.list
apt-get install openssh-server
ip a
poweroof
poweroff
ip a
nano /etc/apt/sources.list
vi /etc/apt/sources.list
apt-get install nano
apt update
vi /etc/apt/sources.list
reboot
apt update
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
vi /etc/apt/sources.list
poweroff
poweroff
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
ping google.com
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
apt upgrade
apt-get install openssh-server
vi /etc/apt/sources.list
poweroff
apt install openssh-server -y
systemctl status ssh
poweroff
poweroff
exit
exit
exit
exit
ls
cd Material_Adicional_TPVMCA/
ls
exit
exit
exit
exit
exit
nano /etc/ssh/sshd_config
poweroff
ip a
openssh -v
openssl -v
apt install openssh-server -y
 apt autoremove
apt install openssh-server -y
nano /etc/ssh/sshd_config
nano
apt install nano -y
nano /etc/ssh/sshd_config
systemctl status ssh
ip a
systemctl restart ssh
systemctl status ssh
ls -s
mkdir /root/.ssh
cd .ssh/
ls
locate
pwd
cd ..
ls
tar -xvf Material_Adicional_TPVMCA.tar.gz 
ls
cd Material_Adicional_TPVMCA/
ls
cp clave_publica.pub /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys 
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys 
systemctl restart ssh
systemctl status ssh
ls
cat clave_privada.txt 
ip a
chmod 700 /root/.ssh/authorized_keys 
systemctl stop ssh
systemctl start ssh
systemctl stop ssh
systemctl status ssh
rm -R /root/.ssh/
systemctl start ssh
systemctl status ssh
nano /etc/ssh/ssh_config
nano /etc/ssh/sshd_config
systemctl restart ssh.service 
systemctl status ssh.service 
nano /etc/ssh/sshd_config
systemctl restart ssh.service 
nano /etc/ssh/sshd_config
systemctl restart ssh.service 
systemctl status ssh.service 
ssh-keygen 
cd ..
cd .ssh
ls

ssh-keygen 
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
nano /etc/network/interfaces
ip a
nano /etc/network/interfaces
nano /etc/network/interfa
s
shutdown -r now
ip a
nano /etc/network/interfaces
nano /etc/network/interfaces
ip a
nano /etc/network/interfaces
systemctl restart networking.service 
systemctl status networking.service 
ip a
reboot
ip a
ip 
ip enp0s3 up
nano /etc/network/interfaces
systemctl restart networking.service 
systemctl status networking.service 
nano /etc/network/interfaces
systemctl restart networking.service 
systemctl status networking.service 
ip a
ping google.com
nano /etc/resolv.conf 
systemctl restart networking.service 
systemctl status networking.service 
ping google.com
nano /etc/network/interfaces
systemctl restart networking.service 
systemctl status networking.service 
ping google.com
apt install apache2 -y
systemctl enable apache2
systemctl start apache2
apt install php libapache2-mod-php -y
systemctl status apache2
cd root
cd /root
ls -l
ls 
cd Material_Adicional_TPVMCA
ls 
cp index.php /var/www/html/
cp logo.png /var/www/html/
cd ...
cd..
cd ..
ls
cd /var{
cd /var
ls
cd /www
cd www
ls
cd html
ls
cd ..
cd ..
cd ..
cd ..
apt install php-mysql -y
systemctl restart apache2
systemctl status apache2
apt install mariadb-server mariadb-client -y
systemctl enable mariadb
systemctl start mariadb
systemctl status mariadb
systemctl status mariadb
ls
ls -l
cd /root
ls -l
ls 
cd Material_Adicional_TPVMCA/
ls -l
cd ..
cd ..
mysql -u root -p < /root/Material_Adicional_TPVMCA/db.sql
cd /root
cd Material_Adicional_TPVMCA/
ls -l
ls
ip a
cd ..
cp mysql
mysql -u root -p
mysql -u root -p
mysql -u root -p
cd Material_Adicional_TPVMCA/
ls 
cd ..
poweroff
cd Material_Adicional_TPVMCA/
ls
cd ..
mysql -u root -p < Material_Adicional_TPVMCA/db.sql
systemctl status mysql
cd /var/www
cd/html
cd /html
cd html
/mariadb <
/mariadb < ~/Material_Adicional_TPVMCA/db.sql
mariadb < ~/Material_Adicional_TPVMCA/db.sql
ls -l
mysql -u root -p
mysql -u root -p
mysql -u root -p
cd ..
cd ..
cd ..
ip a
cd opt
ls 
ls -l
cd ..
fdisk -i
fdisk -l
fdisk 
poweroff
lsblk
fdisk /dev/sdc
lsblk

mkfs -t ext4/dev/sdc1
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
lsblk
ls
cd Material_Adicional_TPVMCA/
ls
cd --
mkdir /www_dir
mkdir /backup_dir
ls
cd Material_Adicional_TPVMCA/
cd Material_Adicional_TPVMCA/
ls
cd --
ls -l
cd /mnt
ls
ls -l
poweroff
cd /var/www/html/
ls
rm index.html 
ls
cd /root/
ls
locate
find
find bkpdir
find backup.dir
find backup
find backup_dir
find /backup_dir
find */backup_dir
lsblk
cd sdc1
cd /srv/
ls
cd ..
cd mnt/
ls
ls
mkdir www_dir
mkdir backup_dir
mount /dev/sdc1 /mnt/www_dir/
mount /dev/sdc2 /mnt/backup_dir/
ls
poweroff
fstab
nano /etc/fstab
lsblk
blkid /dev/sdc1
blkid /dev/sdc2
nano /etc/fstab
nano /etc/fstab
mount -a
systemctl deamon-reload 
systemctl daemon-reload 
ls
cd Material_Adicional_TPVMCA/
ls
cd ..
hostnamectl set-hostname TPServer
nano /etc/hosts
hostname
nano
nano /etc/hosts
cd ..
cd /etc
hostname
cd .. 
cd opt
mkdir scripts
;s
ls
cd scripts
ls
nano backup_full.sh
ls
cd .. 
cd ..
chmod +x /opt/scripts/backup_full.sh
cd /opt
ls
cd scripts
ls -l
./backup_full.sh -help
./backup_full.sh -h
crontab -e
crontab -e
backup_full.sh /var/log /backup_dir
/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
nano backup_full.sh 
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
cd ..
cd ..
ls 
ls -l
cd ..
ls 
cd ~
ls
cd backup_dir
cd /backup_dir
ls
poweroff
cd /opt
ls
cd scripts
nano backup_full.sh 
poweroff
nano backup_full.sh 
cd opt
cd /opt
cd scripts/
nano backup_full.sh 
nano backup_full.sh 
./backup_full.sh -h 
crontab -e
ls -l
nano backup_full.sh 
ls -l
./backup_full.sh -h 
crontab -e
poweroff
lsblk
ls -l
cd Material_Adicional_TPVMCA/
ls -l
cd clave_publica.pup

ls 
poweroff
cd /var
ls
cd www
ls
cd html
ls -l
ip a
cd ..
cd ..
cd ..
cd /root
ls
cd Material_Adicional_TPVMCA/
ls
poweroff
clear
cd /opt
cd scri'pts
cd scripts
cd scripts
nano backup_full.sh 
nano backup_full.sh 
poweroff
cd scripts
cd /opt
cd scripts
nano backup_full.sh 
nano backup_full.sh 
poweroff
cd /ssh
cd ssh
cd .ssh
ls -l
ls
d ..
cd ..
cd /opt
nano backup_full.sh 
cd scripts
nano backup_full.sh 
exit
exit
